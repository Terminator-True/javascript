<template>
  <div class="Form">
    <Form msg="DAW"/>
  </div>
</template>

<script>
// @ is an alias to /src
import Form from '@/components/Form_Component.vue'
export default {
  name: 'FormView',
  components: {
    Form
  }
}
</script>
