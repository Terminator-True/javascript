<template>
<div id="app">
  <Header></Header>
</div>
</template>

<script>
import Header from "./components/Header_Component.vue"

export default {
    name:"app",
    components:{
      Header
    }
}
</script>

<style lang="scss">
@import '../node_modules/bootstrap/scss/bootstrap.scss';

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>


