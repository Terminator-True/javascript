//es una funció javascript per clonar un array que li passem com a paràmetre. 

function copia(ll) {
    const copia_ll= ll.slice(0,ll.length)
    console.log(copia_ll)
}